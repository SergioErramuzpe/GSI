/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.connect;

import BSystem.BusinessSystem;

/**
 *
 * @author Erra
 */
public class BusinessServer {
    
    //Instancia de BusinessSystem
    BusinessSystem bs = BusinessSystem.getBusinessSystem();
    
    /*Se va a crear una good BBDD y la vamos a 
    almacenar en un XML, luego se borra el pedazo de código 
    correspondiente a la creación del XML. Posteriormente se crea una carga
    y guardado del XML para siempre, que corresponde a la BBDD*/
}
